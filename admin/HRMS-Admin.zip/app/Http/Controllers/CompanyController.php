<?php

namespace App\Http\Controllers;
use App\Models\Company;
use App\Models\LoginAuthentication;
use App\Models\AddemployeeMaster;
use App\Models\SetOTP;
use App\Models\addemployeedetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Mail;


class CompanyController extends Controller
{
    public function signup(Request $req){
        $prev_reg_details = Company::where('email',$req->email)->first();

        if ($prev_reg_details) {
            $success        = 'warning';
            $messages       = 'This email already exists. Please try a new one.';
            $emailStatus    = '';
            
        } else {

            $alphabet   = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
            $pass       = array();
            $alphaLength= strlen($alphabet) - 1;
            for ($i = 0; $i < 8; $i++) {
                $n      = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            $verifcationtoken   = implode($pass);

            $registration                       = new Company;
            $registration->uname                = $req->uname;
            $registration->orgname              = $req->orgname;
            $registration->email                = $req->email;
            $registration->phone                = $req->phone;
            $registration->country              = $req->country;
            $registration->timezone             = $req->timezone;
            $registration->dateformat           = $req->dateformat;
            $registration->verifcationtoken     = $verifcationtoken;
            $registration->verificationstatus   = 'no';
            $registration->status               = 'A';
            $registration->ip_address           = $req->ipAddress;
            $registration->session              = '';
            $insertedData                       = $registration->save();

            if($insertedData){
                //authentication

                $loginAuth              = new LoginAuthentication;
                $loginAuth->company_id  = $registration->_id;
                $loginAuth->uname       = $req->uname;
                $loginAuth->email       = $req->email;
                $loginAuth->password    = $req->password;
                $loginAuth->status      = 'A';
                $loginAuth->session     = '';
                $loginAuth->ip_address  = $req->ipAddress;
                $loginAuth->save();

                //email
                $data       = array('name'=>$req->uname,'password'=>$verifcationtoken);
                $tomail     = $req->email;
                $adminmail  = 'kuntal.dev@reddensoft.com';
                $from_mail  = env('MAIL_FROM_ADDRESS');
                $fname      = $req->uname;

                $mail = Mail::send('email_templates.sendwelcomeuser', $data, function ($message) use ($tomail,$fname){
                    $message->from(env('MAIL_FROM_ADDRESS'), $name = 'Reddensoft Employee Portal');
                    $message->subject("Welcome to HRMS", $name = $fname);
                    $message->to($tomail, $name);
                });

                $success    = 'success';
                $messages   = 'Your sign-up was successful. Please verify your email to continue';
                $emailStatus= $mail;
            } else {
                $success    = 'failed';
                $messages   = 'Somthing went wrong';
                $emailStatus= 'failed';
            }
        }

        $response = [
            'success'       => $success,
            'message'       => $messages,
            'emailStatus'   => ($emailStatus)? $emailStatus:''
        ];

        return response()->json($response);
    }

    public function signin(Request $req){

        $emailCheck = Company::where('email',$req->email)->first();
        if (!$emailCheck) {
            $msg        = 'This email does not exist. Please try another one.';
            $success    = 'danger';
        } else {
            $userDetails= LoginAuthentication::where('company_id',$emailCheck->_id)->first();
            $password   = $userDetails->password;
            if ($password == $req->password) {
                $msg        = 'Your have successfully signed in';
                $success    = 'success';
            } else {
                $msg        = 'Password does not match!';
                $success    = 'danger';
            }
        }

        $response = [
            'success' => $success,
            'message' => $msg,
            'companyDetails' => $emailCheck
        ];

        return response()->json($response);
    }

    public function check_email(Request $req){
        $emailCheck = Company::where('email',$req->email)->first();
        if (!$emailCheck) {
            $msg        = 'This email does not exist. Please try another one.';
            $success    = 'danger';
        } else {
            $otp        = rand(000000,999999);
            $data       = array('email'=>$req->email,'otp'=>$otp);
            $tomail     = $req->email;
            $adminmail  = 'kuntal.dev@reddensoft.com';
            $from_mail  = env('MAIL_FROM_ADDRESS');
            $fname      = $emailCheck->uname;

            $mail = Mail::send('email_templates.sendotptouser', $data, function ($message) use ($tomail,$fname){
                $message->from(env('MAIL_FROM_ADDRESS'), $name = 'Reddensoft Employee Portal');
                $message->subject("Welcome to HRMS", $name = $fname);
                $message->to($tomail, $name);
            });

            $sendOTP                       = new SetOTP;
            $sendOTP->email                = $req->email;
            $sendOTP->otp                  = $otp;
            $sendOTP->status               = 'A';
            $sendOTP->ip_address           = $req->ipAddress;
            $sendOTP->session              = '';
            $insertedOTPData               = $sendOTP->save();

            if($insertedOTPData){
                $msg        = 'OTP Sent Successfully to your email inbox';
                $success    = 'success';
            } else {
                $msg        = 'Someting went wrong';
                $success    = 'danger';
            }
        }

        $response = [
            'success' => $success,
            'message' => $msg,
            // 'details' => $prev_reg_details->_id
        ];

        return response()->json($response);
    }

    public function verifymail(Request $req){
        $prev_reg_details = Company::where(['verifcationtoken'=>$req->token,'verificationstatus'=>'no'])->first();
        // dd('test');
        if ($prev_reg_details) {
            $updateverificationstatus = Company::where(['verifcationtoken'=>$req->token,'verificationstatus'=>'no'])->update([
                'verificationstatus' => 'yes',
             ]);
             $success = 'success';
             $msg = 'Email verified successfully.';

        }
        else
        {
            $success = 'success';
            $msg = 'Email verified successfully.';
        }

        $response = [
            'success' => $success,
            'message' => $msg,
        ];

        return response()->json($response);
    }

    public function otp_change_password(Request $req){

        $emailCheck = SetOTP::where('email',$req->email)->orderBy('_id', 'desc')->first();
        if (!$emailCheck) {

            $msg        = 'This email does not exist. Please try again.';
            $success    = 'danger';
        } else {
            if($req->otp === $emailCheck->otp){
                //$emailCheck = SetOTP::where('email',$req->email)->order_by('email', 'desc')->first();

                $updatePassword = LoginAuthentication::where(['email'=>$req->email])->update([
                    'password' => $req->confirmPassword,
                 ]);

                if($updatePassword){
                    $msg        = 'Password Change Successfully';
                    $success    = 'success';
                } else {
                    $msg        = 'Someting went wrong';
                    $success    = 'danger';
                }
            } else {
                $msg        = 'OTP not match';
                $success    = 'danger';
            }
        }

        $response = [
            'success' => $success,
            'message' => $msg,
            'message2' => $req->otp,
            'message3' => $emailCheck->otp,
            // 'details' => $prev_reg_details->_id
        ];

        return response()->json($response);
    }

    public function addemployeemasterdetails(Request $req){

        $checkprev = AddemployeeMaster::where('companyid', $req->company_id)->first();

        if ($checkprev) {
            $updateemp = AddemployeeMaster::where('companyid', $req->company_id)->update([
                'addempdeatils' => $req->info,
            ]);

            // $message = 'Details updated successfully';
        } else {
            $addemp = new AddemployeeMaster;
            $addemp->addempdeatils = $req->info;
            $addemp->companyid = $req->company_id;
            $addemp->save();

            // $message = 'Details added successfully';

        }

        $newempdata = AddemployeeMaster::where('companyid', $req->company_id)->first();

        $response = [
            'success' => 'success',
            'newempdata' => $newempdata,
            'message' => $req->message
        ];

        return response()->json($response);


    }

    public function fetchemployeemasterdetails(Request $req){

        $empdata = AddemployeeMaster::where('companyid', $req->company_id)->first();

        if ($empdata) {
            $formdetails = $empdata->addempdeatils;
        } else {
            $formdetails = false;
        }


        $response = [
            'success' => 'success',
            'formdetails' => $formdetails,
        ];

        return response()->json($response);

    }

    public function addempdetails(Request $req){
        $addemp = new addemployeedetail;
        $addemp->fname = $req->fname;
        $addemp->lname = $req->lname;
        $addemp->gender = $req->gender;
        $addemp->dob = $req->dob;
        $addemp->country = $req->country;
        $addemp->married = $req->married;
        $addemp->empid = $req->empid;
        $addemp->doj = $req->doj;
        $addemp->jobtitle = $req->jobtitle;
        $addemp->dept = $req->dept;
        $addemp->reporting_manager = $req->reporting_manager;
        $addemp->gross_salary = $req->gross_salary;
        $addemp->acc_number = $req->acc_number;
        $addemp->pan = $req->pan;
        $addemp->benifitdoc = $req->benifitdoc;
        $addemp->edu_level = $req->edu_level;
        $addemp->edu_institue = $req->edu_institue;
        $addemp->edu_certificate = $req->edu_certificate;
        $addemp->prev_employer = $req->prev_employer;
        $addemp->emp_skills = $req->emp_skills;
        $addemp->experience_certificate = $req->experience_certificate;
        $addemp->jobexperience = $req->jobexperience;
        $addemp->emp_cv = $req->emp_cv;
        $addemp->emp_id_doc = $req->emp_id_doc;
        $addemp->save();

        $response = [
            'success' => 'success',
            'message' => 'Employee added with success'
        ];

        return response()->json($response);
    }

    public function companyDetailsSetAsDefault(Request $req){
        //attendance
        $AttendanceSetting = AttendanceSetting::where('company_id',$req->companyId)->where('status','A')->first();

        if(!$AttendanceSetting){

            $shiftArray = array('fullday','halfday');
            foreach ($shiftArray as $key => $value) {
                $shiftType                        = new AttendanceShift;
                $shiftType->company_id            = $req->companyId;
                $shiftType->shiftType             = 'general';
                $shiftType->shiftName             = $value;
                $shiftType->shiftFrom             = ($value=='fullday')? $defineFullShiftFrom : $defineFullShiftFrom;
                $shiftType->shiftTo               = ($value=='fullday')? $defineFullShiftTo : $defineHalfShiftTo;
                $shiftType->status                = 'A';
                $shiftType->ip_address            = $req->ipAddress;
                $shiftType->session               = '';
                $insertedData                     = $shiftType->save();
            }
            $roaster                              = new AttendanceRoster;
            $roaster->company_id                  = $req->companyId;
            $roaster->shiftType                   = 'general';
            $roaster->rosterName                  = 'General';
            $roaster->effectiveFrom               = $req->effectiveFrom;
            $roaster->effectiveTo                 = $req->effectiveTo;
            $roaster->workingDaysVaryWeekly       = $req->everyWeekGen;
            $roaster->allWeek                     = //$specifyDateGArrays:'';
            $roaster->status                      = 'A';
            $roaster->ip_address                  = $req->ipAddress;
            $roaster->session                     = '';
            $insertedData                         = $roaster->save();

            if($insertedData){
                $aSetting                         = new AttendanceSetting;
                $aSetting->company_id             = $req->companyId;
                $aSetting->shiftType              = 'General';
                $aSetting->status                 = 'A';
                $aSetting->ip_address             = $req->ipAddress;
                $aSetting->session                = '';
                $insertedASData                     = $aSetting->save();
            }
            

            if($insertedASData){
                $success    = 'success';
                $messages   = 'Attendance Setting added successfully';
            } else {
                $success    = 'failed';
                $messages   = 'Somthing went wrong';
            }
        } else {
            $updateAttendance = AttendanceSetting::where(['_id'=>$AttendanceSetting->_id])->update([
                'shiftType' => $req->shiftType
            ]);
            if($req->shiftType==='General'){
                $shiftArray = array('fullday','halfday');
                foreach ($shiftArray as $key => $value) {
                    $updateAttendance = AttendanceShift::where(['company_id'=>$req->companyId,'shiftType'=>'general','shiftName'=>$value])->update([
                        'shiftFrom' => ($value=='fullday')? $req->defineFullShiftFrom : $req->defineHalfShiftFrom,
                        'shiftTo'   => ($value=='fullday')? $req->defineFullShiftTo : $req->defineHalfShiftTo
                    ]);
                }
                $updateAttendance = AttendanceRoster::where(['company_id'=>$req->companyId,'shiftType'=>'general','rosterName'=>'General'])->update([
                    'effectiveFrom'         => $req->effectiveFrom,
                    'effectiveTo'           => $req->effectiveTo,
                    'workingDaysVaryWeekly' => $req->everyWeekGen,
                    'allWeek'               => //$specifyDateGArrays

                ]);
            }
            if($updateAttendance){
                $success    = 'success';
                $messages   = 'Attendance Setting updated successfully';
            } else {
                $success    = 'failed';
                $messages   = 'Somthing went wrong';
            }
        }

        //department
        //$departmentArray         = $req->departmentArray;

        $departmentArray = array(
            "Sales and Marketing",
            "Finance and Accounting",
            "Human Resources",
            "Information Technology",
            "Customer Service / Support",
            "Production / Operations",
            "Research and Development",
            "Supply Chain and Logistics",
            "Quality Assurance / Quality Control",
            "Legal and Compliance",
            "Public Relations",
            "Administration and Office Management",
            "Training and Development",
            "Health and Safety",
            "Marketing",
            "Product Management"
        );

        if($departmentArray>0){
            foreach ($departmentArray as $key => $value) {
                $insert              = new Department;
                $insert->company_id  = $req->company_id;
                $insert->name        = $value['departmentName'];
                $insert->status      = 'A';
                $insert->session     = '';
                $insert->ip_address  = $req->ipAddress;
                $insertedData        = $insert->save();
            }
        }
        
        if($insertedData){
            $success    = 'success';
            $messages   = 'Created successfully';
        } else {
            $success    = 'failed';
            $messages   = 'somthing went wrong';
        }

        //designation
        //$designationArray         = $req->designationArray;
        $designationArray = array('Sales Representative / Sales Executive','
            Sales Manager','
            Marketing Coordinator','
            Marketing Manager','
            Business Development Manager','
            Accountant','
            Financial Analyst','
            Controller','
            Chief Financial Officer (CFO)','
            Auditor','
            HR Assistant','
            HR Generalist','
            HR Manager','
            Recruitment Specialist','
            Training and Development Manager','
            IT Support Specialist','
            Systems Administrator','
            Software Developer','
            IT Project Manager','
            Chief Information Officer (CIO)','
            Customer Service Representative','
            Customer Service Supervisor','
            Customer Success Manager','
            Technical Support Specialist','
            Production Worker','
            Operations Manager','
            Plant Manager','
            Quality Control Inspector','
            Research Analyst','
            Product Developer','
            R&D Manager','
            Logistics Coordinator','
            Supply Chain Manager','
            Purchasing Manager','
            Quality Assurance Analyst','
            Quality Control Manager','
            Legal Assistant','
            Compliance Officer','
            Corporate Counsel','
            Public Relations Specialist','
            Communications Manager','
            Administrative Assistant','
            Office Manager','
            Training Coordinator','
            Learning and Development Specialist','
            Safety Officer','
            Health and Safety Manager','
            Marketing Assistant','
            Brand Manager','
            Product Manager','
            Product Owner'
        );
        
        if($designationArray>0){
            foreach ($designationArray as $key => $value) {
                $insert              = new Designation;
                $insert->company_id  = $req->company_id;
                $insert->name        = $value['designationName'];
                $insert->status      = 'A';
                $insert->session     = '';
                $insert->ip_address  = $req->ipAddress;
                $insertedData        = $insert->save();
            }
        }
        
        if($insertedData){
            $success    = 'success';
            $messages   = 'Created successfully';
        } else {
            $success    = 'failed';
            $messages   = 'somthing went wrong';
        }

        //leave management

        $leaveDetails = Leave::where('company_id', $req->companyId)->where('leaveName',$req->leaveName)->first();
        if(!$leaveDetails){

            $insert                     = new Leave;
            $insert->company_id         = $req->companyId;
            $insert->leaveName          = $req->leaveName;
            $insert->paidLeave          = $req->paidLeave;
            $insert->effectiveAfter     = $req->effectiveAfter;
            $insert->effectiveAfterDate = $req->effectiveAfterDate;
            $insert->leaveSpanFromDate  = $req->leaveSpanFromDate;
            $insert->leaveSpanToDate    = $req->leaveSpanToDate;
            $insert->leaveCarry         = $req->leaveCarry;
            $insert->leaveCurryFwdLimit = $req->leaveCurryFwdLimit;
            $insert->leaveCncashment    = $req->leaveCncashment;
            $insert->leaveCncashmentLimit = $req->leaveCncashmentLimit;
            $insert->leaveApplicable    = $req->leaveApplicable;
            $insert->leaveApplicableData= $req->leaveApplicableData;
            $insert->MaritalStatus      = $req->MaritalStatus;
            $insert->MaritalStatusData  = $req->MaritalStatusData;
            $insert->leaveDepartment    = $req->leaveDepartment;
            $insert->location           = $req->location;
            $insert->leaveDesignation   = $req->leaveDesignation;
            $insert->leaveSandwitch     = $req->leaveSandwitch;
            $insert->leaveDuration      = $req->leaveDuration;
            $insert->status             = 'A';
            $insert->session            = '';
            $insert->ip_address         = $req->ipAddress;
            $insertedData               = $insert->save();
            
            if($insertedData){
                $success    = 'success';
                $messages   = 'Leave added successfully';
            } else {
                $success    = 'failed';
                $messages   = 'somthing went wrong';
            }
        } else {
            $updatedData    = Leave::where(['_id'=>$leaveDetails->_id])->update([

                'leaveName'             => $req->leaveName,
                'paidLeave'             => $req->paidLeave,
                'effectiveAfter'        => $req->effectiveAfter,
                'effectiveAfterDate'    => $req->effectiveAfterDate,
                'leaveSpanFromDate'     => $req->leaveSpanFromDate,
                'leaveSpanToDate'       => $req->leaveSpanToDate,
                'leaveCarry'            => $req->leaveCarry,
                'leaveCurryFwdLimit'    => $req->leaveCurryFwdLimit,
                'leaveCncashment'       => $req->leaveCncashment,
                'leaveCncashmentLimit'  => $req->leaveCncashmentLimit,
                'leaveApplicable'       => $req->leaveApplicable,
                'leaveApplicableData'   => $req->leaveApplicableData,
                'MaritalStatus'         => $req->MaritalStatus,
                'MaritalStatusData'     => $req->MaritalStatusData,
                'leaveDepartment'       => $req->leaveDepartment,
                'location'              => $req->location,
                'leaveDesignation'      => $req->leaveDesignation,
                'leaveSandwitch'        => $req->leaveSandwitch,
                'leaveDuration'         => $req->leaveDuration
            ]);
            if($updatedData){
                $success    = 'success';
                $messages   = 'Leave updated successfully';
            } else {
                $success    = 'failed';
                $messages   = 'somthing went wrong';
            }
        }

        $response = [
            'success'       => $success,
            'message'       => $messages
        ];

        return response()->json($response);
    }

    //function

}
