<?php

namespace App\Http\Controllers;
use App\Models\Designation;
use App\Models\Department;
use MongoDB\BSON\ObjectId;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Mail;


class CompanyDesignationController extends Controller
{

    public function getDesignationList2(){

        // // $designationList = Designation::with('getDepartmentId')->where('status', 'A')->get();
        // $designationList = Designation::where('status', 'A')->get()->map(function ($designation) {
        //     $designation->load('getDepartmentId');
        //     return $designation;
        // });

        // Retrieve designations with a specific status
        $designations = Designation::where('status', 'A')->get();

        // // Eager load department data manually using map
        // $designationList = $designations->map(function ($designation) {
        //     $designation->department = $designation->getDepartmentId()->first();
        //     return $designationId;
        // });

        // $designationList->each(function ($designation) {
        //     $designation->load('getDepartmentId');
        // });

        // $designationList = Designation::where('status', 'A')->get()->map(function ($designation) {
        //     $designation->load('getDepartmentId');
        //     return $designation;
        // });

        $designationList = [];
        foreach ($designations as $designation) {
            $departmentData = Department::find($designation->departmentId);
            if ($departmentData) {
                $designation->department = $departmentData;
                $designationList[] = $designation;
            }
        }

        $response = [
            'success'           => 'success',
            // 'message'           => $req->message,
            'designationList'   => $designationList
        ];

        return response()->json($response);
    }

    public function addDesignation(Request $req){
        
        $designationArray         = $req->designationArray;
        
        if($designationArray>0){
            foreach ($designationArray as $key => $value) {
                if($value['designationName']!=''){
                    $insert              = new Designation;
                    $insert->company_id  = $req->company_id;
                    $insert->departmentId= $value['departmentId'];
                    $insert->name        = $value['designationName'];
                    $insert->status      = 'A';
                    $insert->session     = '';
                    $insert->ip_address  = $req->ipAddress;
                    $insertedData        = $insert->save();
                } else {
                    $insertedData = false;
                }
            }
        }
        
        if($insertedData){
            $success    = 'success';
            $messages   = 'Created successfully';
        } else {
            $success    = 'failed';
            $messages   = 'somthing went wrong';
        }

        $response = [
            'success'       => $success,
            'message'       => $messages
            //'data'       => $req->designationArray
        ];

        return response()->json($response);
    }

    public function editDesignation(Request $req){
        $updatedData    = Designation::where(['_id'=>$req->id])->update([
            'departmentId'  => $req->departmentId,
            'name'          => $req->designationName
        ]);

        if($updatedData){
            $success    = 'success';
            $messages   = 'Update successfully';
        } else {
            $success    = 'failed';
            $messages   = 'somthing went wrong';
        }

        $response = [
            'success'       => $success,
            'message'       => $messages
            //'data'       => $req->departmentArray
        ];

        return response()->json($response);
    }

    public function deleteDesignation(Request $req){
        $deletedData    = Designation::where(['_id'=>$req->id])->update([
            'status' => 'D',
        ]);

        if($deletedData){
            $success    = 'success';
            $messages   = 'Deleted successfully';
        } else {
            $success    = 'failed';
            $messages   = 'somthing went wrong';
        }

        $response = [
            'success'       => $success,
            'message'       => $messages
            //'data'       => $req->departmentArray
        ];

        return response()->json($response);
    }

    public function getDepartmentWiseDesignationList(Request $req){

        $designationList = Designation::where('departmentId', $req->code)->where('status', 'A')->get();
        $response = [
            'success'           => 'success',
            // 'message'           => $req->message,
            'designationList'   => $designationList
        ];

        return response()->json($response);
    }


    //function

}
